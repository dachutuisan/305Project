package com.sdu.covid2019CMS.action;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.sdu.covid2019.vo.Info;
import com.sdu.covid2019CMS.service.CMSInfoService;

public class CMSInfoAction extends ActionSupport implements ModelDriven<Info>{

	private Info info = new Info();

	@Override
	public Info getModel() {
		// TODO Auto-generated method stub
		return info;
	}
	
	private CMSInfoService cmsInfoService;
	public void setCmsInfoService(CMSInfoService cmsInfoService) {
		this.cmsInfoService = cmsInfoService;
	}

	public String add() {
		System.out.println(info.getIdate());
		cmsInfoService.add(info);
		return "success";
	}
	
}
