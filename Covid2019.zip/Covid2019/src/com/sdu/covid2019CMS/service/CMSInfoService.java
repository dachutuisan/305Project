package com.sdu.covid2019CMS.service;

import com.sdu.covid2019.vo.Info;
import com.sdu.covid2019CMS.dao.CMSInfoDao;

public class CMSInfoService {

	private CMSInfoDao cmsInfoDao;

	public void setCmsInfoDao(CMSInfoDao cmsInfoDao) {
		this.cmsInfoDao = cmsInfoDao;
	}

	public void add(Info info) {
		// TODO Auto-generated method stub
		cmsInfoDao.add(info);
	}
	
}
