package com.sdu.covid2019CMS.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.sdu.covid2019.vo.Info;
public class CMSInfoDao extends HibernateDaoSupport{


	public void add(Info info) {
		// TODO Auto-generated method stub
		Date date1 = info.getIdate();
		SimpleDateFormat sdft = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date1str = sdft.format(date1);
		date1str = date1str+" 00:00:00";
		Date idate = null;
		try {
			idate = sdft.parse(date1str);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		info.setIdate(idate);
		
		//
		String hql = "from Info i where i.idate = ?";
		List<Info> list = this.getHibernateTemplate().find(hql,idate);
		if(list==null||list.size()<1) {
			this.getHibernateTemplate().save(info);
		}else {
			info.setIid(list.get(0).getIid());
			this.getHibernateTemplate().update(info);
		}
	}

	
}
