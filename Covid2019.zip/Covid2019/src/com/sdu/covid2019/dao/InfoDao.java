package com.sdu.covid2019.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.sdu.covid2019.vo.Info;

public class InfoDao extends HibernateDaoSupport{

	public List<Info> findByDate(Date date) {
		
		Date date1 = date;
		long oneDayTime = 1000*3600*24;
		// ���date2���Ǽ�1���ʱ��
		Date date2 = new Date(date1.getTime() - oneDayTime);
		SimpleDateFormat sdft = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date1str = sdft.format(date1);
		String date2str  = sdft.format(date2);
		System.out.println(date1str); 
		System.out.println(date2str);
		
		Date from=null;
		Date to=null;
		try {
			from = sdft.parse(date2str);
			to = sdft.parse(date1str);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DetachedCriteria criteria = DetachedCriteria.forClass(Info.class);
		
		criteria.add(
                // ������
                Restrictions.and(
                        // ȡ����
                        Restrictions.gt("idate", from),
                        // ȡС�ڵ���less than or equal
                        Restrictions.le("idate",to)
                                ));
		List<Info> list = this.getHibernateTemplate().findByCriteria(
				criteria);
        return list;
	}

}
