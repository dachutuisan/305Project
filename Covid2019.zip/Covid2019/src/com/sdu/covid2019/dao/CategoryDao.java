package com.sdu.covid2019.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.sdu.covid2019.vo.Category;

public class CategoryDao extends HibernateDaoSupport{

	public List<Category> findAll() {
		String hql = "from Category";
		List<Category> list =this.getHibernateTemplate().find(hql);
		return list;
	}

}
