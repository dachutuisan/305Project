package com.sdu.covid2019.vo;

import java.util.Date;

public class Info {

	private Integer iid;
	private Date idate;
	private String worldmap;
	private String chinamap;
	private String tiaoxing;
	private String zhexian;
	private String rosemap;
	private String number;
	public Integer getIid() {
		return iid;
	}
	public void setIid(Integer iid) {
		this.iid = iid;
	}
	public Date getIdate() {
		return idate;
	}
	public void setIdate(Date idate) {
		this.idate = idate;
	}
	public String getWorldmap() {
		return worldmap;
	}
	public void setWorldmap(String worldmap) {
		this.worldmap = worldmap;
	}
	public String getChinamap() {
		return chinamap;
	}
	public void setChinamap(String chinamap) {
		this.chinamap = chinamap;
	}
	public String getTiaoxing() {
		return tiaoxing;
	}
	public void setTiaoxing(String tiaoxing) {
		this.tiaoxing = tiaoxing;
	}
	public String getZhexian() {
		return zhexian;
	}
	public void setZhexian(String zhexian) {
		this.zhexian = zhexian;
	}
	public String getRosemap() {
		return rosemap;
	}
	public void setRosemap(String rosemap) {
		this.rosemap = rosemap;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	
	
}
