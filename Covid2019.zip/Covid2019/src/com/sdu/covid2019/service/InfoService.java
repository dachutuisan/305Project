package com.sdu.covid2019.service;

import java.util.Date;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.sdu.covid2019.dao.InfoDao;
import com.sdu.covid2019.vo.Info;

public class InfoService {

	private InfoDao infoDao;
	
	public void setInfoDao(InfoDao infoDao) {
		this.infoDao = infoDao;
	}

	public List<Info> findByDate(Date date) {
		// TODO Auto-generated method stub
		return infoDao.findByDate(date);
	}

}
