package com.sdu.covid2019.service;

import java.util.List;

import com.sdu.covid2019.dao.CategoryDao;
import com.sdu.covid2019.vo.Category;

public class CategoryService {
	private CategoryDao categoryDao;

	public void setCategoryDao(CategoryDao categoryDao) {
		this.categoryDao = categoryDao;
	}


	public List<Category> findAll() {
		// TODO Auto-generated method stub
		return categoryDao.findAll();
	}


}
