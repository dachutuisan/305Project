package com.sdu.covid2019.action;

import java.util.Date;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.sdu.covid2019.service.InfoService;
import com.sdu.covid2019.vo.Info;

public class InfoAction extends ActionSupport implements ModelDriven<Info> {

	// ģ�������Ķ���
	// ����ģ���������μ�https://blog.csdn.net/qq_33800083/article/details/80251112
	private Info info = new Info();

	public Info getModel() {
		return info;
	}

	private InfoService infoService;

	public void setInfoService(InfoService infoService) {
		this.infoService = infoService;
	}

	public String findByDate() {
		System.out.println(info.getIdate());
		List<Info> iList = infoService.findByDate(info.getIdate());
		ActionContext.getContext().getSession().put("iList", iList);
		//System.out.println(iList.get(0).getWorldmap());
		return "success";
	}
}
