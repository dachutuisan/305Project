package com.sdu.covid2019.action;

import java.util.List;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.sdu.covid2019.service.*;
import com.sdu.covid2019.vo.*;

public class IndexAction extends ActionSupport {

	private CategoryService categoryService;

	public void setCategoryService(CategoryService categoryService) {
		this.categoryService = categoryService;
	}

	/*
	 * ִ����ҳ���ʵķ���
	 */
	public String execute() {
		List<Category> cList = categoryService.findAll();
		// ��һ���������session��
		ActionContext.getContext().getSession().put("cList", cList);
		System.out.println(cList.get(1).getCname());
		return "index";

	}
}
